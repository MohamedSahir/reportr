﻿using BoldReports.Web.ReportViewer;
using BoldReports.Writer;
using Newtonsoft.Json;
using Syncfusion.Pdf.Graphics;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace ReportViewer.Controller
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ReportApiController : ApiController, IReportController
    {
        private FontStyle fontSize;

        public object PostReportAction(Dictionary<string, object> jsonResult)
        {
            return ReportHelper.ProcessReport(jsonResult, this);
        }

        //Get action for getting resources from the report
        [System.Web.Http.ActionName("GetResource")]
        [AcceptVerbs("GET")]
        public object GetResource(string key, string resourcetype, bool isPrint)
        {
            return ReportHelper.GetResource(key, resourcetype, isPrint);
        }

        //Method will be called when initialize the report options before start processing the report        
        public void OnInitReportOptions(ReportViewerOptions reportOption)
        {
            
        }

        //Method will be called when reported is loaded
        public void OnReportLoaded(ReportViewerOptions reportOption)
        {
            //if (reportOption.ReportModel.PDFOptions == null)
            //{
            //    reportOption.ReportModel.PDFOptions = new PDFOptions();
            //}
            //this.AddFonts(reportOption.ReportModel.PDFOptions);
        }

        private void AddFonts(PDFOptions pdfOpt)
        {
            this.AddFont(pdfOpt, "Gilroy");
        }

        public void AddFont(PDFOptions pdfOpt, string name)
        {
            var path = HttpContext.Current.Request.PhysicalApplicationPath;
            FileStream inputStream = new FileStream(path+@"\App_Data\Gilroy-Regular.ttf", FileMode.Open, FileAccess.Read);
            if (pdfOpt.Fonts == null)
            {
                pdfOpt.Fonts = new Dictionary<string, Stream>(StringComparer.Ordinal);
            }
            pdfOpt.Fonts.Add(name, inputStream);
        }
    }
}