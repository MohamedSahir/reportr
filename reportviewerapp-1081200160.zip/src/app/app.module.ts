import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BOLD_REPORTVIEWER_COMPONENTS } from '@boldreports/angular-reporting-components/src/reportviewer.component';
import { AppComponent } from './app.component';

import '@boldreports/javascript-reporting-controls/Scripts/data-visualization/ej.bulletgraph.min';
import '@boldreports/javascript-reporting-controls/Scripts/data-visualization/ej.chart.min';
import '@boldreports/javascript-reporting-controls/Scripts/data-visualization/ej.circulargauge.min';
import '@boldreports/javascript-reporting-controls/Scripts/data-visualization/ej.lineargauge.min';
import '@boldreports/javascript-reporting-controls/Scripts/data-visualization/ej.map.min';

@NgModule({
  declarations: [
    AppComponent,
    BOLD_REPORTVIEWER_COMPONENTS
  ],
imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
