import { Component,ViewChild } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'reportviewerapp';
  public serviceUrl: string;
  public reportData: any;

    constructor() {
      this.serviceUrl = 'http://localhost:53810/api/Home';
      this.reportData = [{
        value: [
             { SalesOrderID: 43659, TotalDue: 23153, CustomerID: 29825, StateProvinceCode: 'GA', Store: 'Better Bike Shop' },
             { SalesOrderID: 43673, TotalDue: 4216, CustomerID: 29844, StateProvinceCode: 'NH', Store: 'Seventh Bike Store' },
             { SalesOrderID: 43675, TotalDue: 6434, CustomerID: 29827, StateProvinceCode: 'MO', Store: 'First Bike Store' }
            ],
         name: "StoreSales"
             }]; 
    }
    reportExport(args){
      args.FormValues.push({
    key:   "Authorization",
    value: "the value"
});
    }

  button1() {
    debugger;
   var dataSources = [{
      value: [
           { SalesOrderID: 1, TotalDue: 1, CustomerID: 1, StateProvinceCode: 'GA', Store: 'Better Bike Shop' },
           { SalesOrderID: 2, TotalDue: 2, CustomerID: 2, StateProvinceCode: 'NH', Store: 'Seventh Bike Store' },
           { SalesOrderID: 3, TotalDue: 3, CustomerID: 3, StateProvinceCode: 'MO', Store: 'First Bike Store' }
          ],
       name: "StoreSales"
           }]  ;   

           var reportObject = $("#viewer").data('ejReportViewer');
           reportObject.setModel({ 
             dataSources: dataSources 
       }); 
  }
  button2() {
    debugger;
    var dataSources = [{
      value: [
           { SalesOrderID: 4, TotalDue: 4, CustomerID: 4, StateProvinceCode: 'GA', Store: 'Better Bike Shop' },
           { SalesOrderID: 5, TotalDue: 5, CustomerID: 5, StateProvinceCode: 'NH', Store: 'Seventh Bike Store' },
           { SalesOrderID: 6, TotalDue: 6, CustomerID: 6, StateProvinceCode: 'MO', Store: 'First Bike Store' }
          ],
       name: "StoreSales"
           }]  ;   

           var reportObject = $("#viewer").data('ejReportViewer');
           reportObject.model.dataSources = dataSources;
           reportObject.refresh();
  }
  button3() {
    debugger;
    var dataSources = [{
      value: [
           { SalesOrderID: 7, TotalDue: 7, CustomerID: 7, StateProvinceCode: 'GA', Store: 'Better Bike Shop' },
           { SalesOrderID: 8, TotalDue: 8, CustomerID: 8, StateProvinceCode: 'NH', Store: 'Seventh Bike Store' },
           { SalesOrderID: 9, TotalDue: 9, CustomerID: 9, StateProvinceCode: 'MO', Store: 'First Bike Store' }
          ],
       name: "StoreSales"
           }]  ;   

    var reportObject = $("#viewer").data('ejReportViewer');
    reportObject.model.dataSources = dataSources;
    reportObject.refresh;

  }

}