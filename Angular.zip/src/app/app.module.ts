import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// Imported Syncfusion button module from buttons package.
import { ButtonModule } from '@syncfusion/ej2-angular-buttons';
import { EJ_REPORTVIEWER_COMPONENTS } from '@syncfusion/reporting-angular/src/ej/reportviewer.component';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    EJ_REPORTVIEWER_COMPONENTS
  ],
imports: [
    BrowserModule,
    ButtonModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }